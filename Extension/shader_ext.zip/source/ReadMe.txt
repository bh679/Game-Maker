

You need the DirectX 8.1 SDK and GMAPI 0.6.2 to compile this.
  
If you get errors about cilib.lib or similar, add it to your linker's ignore list.
