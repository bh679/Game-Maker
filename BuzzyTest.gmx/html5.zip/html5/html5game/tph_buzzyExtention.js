function buzzyTest(arg1)
{
	alert(arg1);
}