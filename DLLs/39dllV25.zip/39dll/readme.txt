39dll by 39ster

In your project select Merge game and than choose DllScripts.gm6. This will 
copy all the dll scripts into your project and keep the folder structure. You can also
just import the .gml file.