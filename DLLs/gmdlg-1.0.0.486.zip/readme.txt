This DLL lets you do the following in your Game Maker Games:
Display 7 brand new common dialog boxes:
Wait box
Terms of Use box
Quick Help box
Calendar box
List Items box
Authorization box
Track Bar box

Read through the comments in the scripts in the included gmd. They will tell you what the functions do and their return values.
I hope you will find this useful.

DISCLAIMER:
I ain't responsible for anything any file provided to you or other people by me has done. Use at your own risk!

LICENCE:
You may distribute this DLL with your Game Maker game, and you don't have to pay me money even if you sell it. All that I require is for you to put this in the credits: "Some functions were provided by the GM Dialog DLL, by Cameron MacGregor, http://camzmac.com/"

My website: http://camzmac.com/
My email address #1: me@camzmac.com
My email address #2: camzmac@gmail.com
My COPA Online username: camzmac
My username at the GMC: camzmac
MSN email address: camzmac@hotmail.com

Ok, so if you need to contact me, you have my contact info.